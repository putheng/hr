<template>
<main class="app-main">
	<!-- .wrapper -->
	<div class="wrapper">
		<!-- .page -->
		<div class="page">
			<!-- .page-inner -->
			
			<div class="page-inner">
				<router-view></router-view>
				<!-- /.page-section -->
			</div>
			<!-- /.page-inner -->
		</div>
		<!-- /.page -->
	</div>
	<!-- /.wrapper -->
</main>
</template>

<script>
	export default {

	}
</script>