<template>
	
	<li class="nav-item dropdown header-nav-dropdown">
		<a class="nav-link" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="oi oi-grid-three-up"></span></a>
		<div class="dropdown-arrow"></div>
		<!-- .dropdown-menu -->
		<div class="dropdown-menu dropdown-menu-rich dropdown-menu-right">
			<!-- .dropdown-sheets -->
			<div class="dropdown-sheets">
				<!-- .dropdown-sheet-item -->
				<div class="dropdown-sheet-item">
					<a href="#" class="tile-wrapper">
						<span class="tile tile-lg bg-indigo">
							<i class="oi oi-people"></i>
						</span>
						<span class="tile-peek">Teams</span>
					</a>
				</div>
				<!-- /.dropdown-sheet-item -->
			</div>
			<!-- .dropdown-sheets -->
		</div>
		<!-- .dropdown-menu -->
	</li>
	
</template>

<script>
	export default {
		
	}
</script>