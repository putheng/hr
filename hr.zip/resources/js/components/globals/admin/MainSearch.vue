<template>
	<div class="top-bar-item top-bar-item-full">
		<!-- .top-bar-search -->
		<form class="top-bar-search">
			<div class="input-group input-group-search">
				<div class="input-group-prepend">
					<span class="input-group-text"><span class="oi oi-magnifying-glass"></span></span>
				</div>
				<input type="text" class="form-control" aria-label="Search" placeholder="Search">
			</div>
		</form>
		<!-- /.top-bar-search -->
	</div>
</template>

<script>
	export default {
		
	}
</script>