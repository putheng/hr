export default {
	validation: [],
	error: null,
	loading: false,
	message: null,
	showMessage: false
}