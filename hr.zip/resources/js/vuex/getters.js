export const getValidationErrors = (state) => state.validation

export const getLoading = (state) => state.loading

export const getError = (state) => state.error

export const getMessage = (state) => state.message

export const showMessage = (state) => state.showMessage