export default {
	user: {},
	resumes: [],
	listing: []
}