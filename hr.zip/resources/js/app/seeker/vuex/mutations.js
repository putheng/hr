export const setUser = (state, data) => {
    state.user = data
}

export const setResume = (state, resumes) => {
    state.resumes = resumes
}

export const setFavorite = (state, favorite) => {
    state.listing = favorite
}