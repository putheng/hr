export const getUser = (state) => {
    return state.user
}

export const getResumes = (state) => {
    return state.resumes
}

export const getFavorite = (state) => {
    return state.listing
}