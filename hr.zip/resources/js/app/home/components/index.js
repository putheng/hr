import Vue from 'vue'

export const Home = Vue.component('home', require('./Home.vue').default)