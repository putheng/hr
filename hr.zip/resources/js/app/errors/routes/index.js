import { NotFound } from '../components'

export default [
    {
        path: '/404',
        component: NotFound
    }
]
