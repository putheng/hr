import Vue from 'vue'

export const NotFound = Vue.component('not-found', require('./NotFound').default)