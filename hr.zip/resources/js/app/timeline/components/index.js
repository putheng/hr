import Vue from 'vue'

export const Timeline = Vue.component('timeline', require('./Timeline.vue').default)