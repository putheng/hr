export default {
	packages: [],
	package: [],
	user: [],
	company: [],
	listing: [],
	packages: [],
	deposits: [],
	paymentGatway: [],
	resume: [],
}