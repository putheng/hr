export default {
    user: {
        authenticated: false,
        data: null
    }
}
