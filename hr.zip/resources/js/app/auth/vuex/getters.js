export const user = (state) => {
    return state.user
}