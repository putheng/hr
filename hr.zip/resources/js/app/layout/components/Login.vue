<template>
    <div class="row">

    </div>
</template>

<script>
    import { mapActions } from 'vuex'

    export default {
        //
    }
</script>
