import Vue from 'vue'

//export const Login = Vue.component('login', require('./Login.vue').default)