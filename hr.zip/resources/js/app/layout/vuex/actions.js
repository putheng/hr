import axios from 'axios'

/*

export const fetchValue = ({commit}) => {
	return axios.get('/api/value/show').then((response) => {
		commit('setValue', response.data.data)

		return Promise.resolve(response)
	})
}

 */