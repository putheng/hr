/*
export const value = (state) => {
    return state.value
}
 */