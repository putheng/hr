/*
export const setValue = (state, data) => {
    state.value = data
}
 */