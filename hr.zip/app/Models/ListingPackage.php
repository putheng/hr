<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ListingPackage extends Model
{
    protected $table = 'listing_package';

    public function package()
    {
    	
    }
}
