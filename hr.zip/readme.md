## Vue components

#### header activities notification
```vue
<activities></activities>
```

#### header messages notification
```vue
<messages></messages>
```

#### header sheets
```vue
<sheets></sheets>
```